# GitHub Actions 构建

将源码提交到仓库。工作流会在 main、master 或 coloros-debloater-build 分支收到推送时运行，也支持从默认分支上的 Actions 页面手动启动。

在成功运行的 Artifacts 中下载 ColorOSDebloater-debug-apk，解压得到 app-debug.apk。APK 使用调试签名。
